
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'shehanp12',
  applicationName: 'backend',
  appUid: 'dVCTTKR7n2KSNmH2XT',
  orgUid: 'c81da065-b777-4a43-a3f1-45f870a9d6f8',
  deploymentUid: '3313367c-f649-4ecd-907c-ed08cc764100',
  serviceName: 'libraryManagmentSystem',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'libraryManagmentSystem-prod-createUser', timeout: 6 };

try {
  const userHandler = require('./createUser.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}